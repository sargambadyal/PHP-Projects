<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>YANTRIK KRISHI</title>
<meta name="keywords" content="" />
<meta name="description" content="" />
<link href='http://fonts.googleapis.com/css?family=Archivo+Narrow:400,700|Open+Sans:400,600,700' rel='stylesheet' type='text/css'>
<link href="default.css" rel="stylesheet" type="text/css" media="all" />
</head>
<body style="background-image:url(images/back.jpg);background-height:500px;background-position:center;">
<div id="wrapper">
	<div id="header-wrapper">
		<div id="header" class="container">
			<div id="logo">
				<h2><a href="#">Yantrik Krishi</a></h2>
			</div>
			<div id="menu">
		<ul>
			<li class="current_page_item"><a href="home.php">Home</a></li>
			<li><a href="signup.php">SignUp</a></li>
			<li><a href="login.php">Login</a></li>
			<li><a href="tutorial.php">Tutorials</a></li>
			<li class="last"><a href="contact.php">Contact</a></li>
		</ul>
		</div>
		</div>
	</div>
	<div id="page" class="container">
		<div id="content" style="width:1200px;">
		<h1> How to use this Website?</h1>
		<a href="tamil.php"/>தமிழ் &nbsp &nbsp </a><a href="hindi.php"/>हिंदी&nbsp &nbsp </a><a href="urdu.php"/>اردو &nbsp &nbsp </a><a href="telgu.php"/>తెలుగు &nbsp &nbsp </a>
			<div>
			<h2>चरण 1:</h2>
			<p style="height:100px;width:900px;">अपने वेबपेज "http://www.yantrikkrishi.com": यूआरएल टाइप करें. यह हमारे घर पृष्ठ पर ले जाएगा. 
			अब पहले से ही मौजूदा उपयोगकर्ताओं के लिए "प्रवेश" क्लिक करें वैकल्पिक रूप से नए उपयोगकर्ताओं के लिए "पंजीकरण" पृष्ठ क्लिक करें.</p>
			<img src="images/demo1.jpg" height="400px" width="500px">
			</div>
				
			<div>
			<h2>चरण 2:</h2>
			<p style="height:100px;width:900px;">अब लिंक "किसानों के लिए पंजीकरण" क्लिक करें. और, नाम की तरह विवरण के साथ फार्म भरने
उपयोगकर्ता नाम, पासवर्ड, वर्ग आदि. अंत में सबमिट बटन दबाएँ. </p>
			<img src="images/demo2.jpg" height="400px" width="500px">
			</div>	
				
			<div>
			<h2>चरण 3:</h2>
			<p style="height:100px;width:900px;">पंजीकरण के बाद पृष्ठ लॉगइन करने के लिए जाना. अपने यूज़रनेम और पासवर्ड भरें. सबमिट क्लिक करें.
किसान व्यक्तिगत पोर्टल के रूप में इस प्रकार खुलेगा</p>
			<img src="images/demo3.jpg" height="400px" width="500px">
			</div>
			
		</div>
		
	</div>
	<div id="footer">
		<p>Copyright (c) Sargam</p>
	</div>
</div>
</body>
</html>
